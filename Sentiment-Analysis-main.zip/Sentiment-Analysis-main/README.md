# Sentiment-Analysis
Sentiment Analysis Classifier with Machine Learning Models

### Topics and Contents
This repository contains my projects on Sentiment Analysis from customer reviews.

### Environment
I did all of this project on Google Colaboratory. Check it out in this link:

[Sentiment Analysis on Google Colab](https://colab.research.google.com/drive/1Jb0-XtSdEoTIYw6suN4nzlao4vaXX0JY?usp=sharing)

### Reference
Most of the references and descriptions of this project are in the notebooks.

### Notes
Information about the dataset used in the project is also in the notebook. I also put the dataset (in CSV format) in this repository.
